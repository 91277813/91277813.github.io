@echo off
chcp 65001 >nul
title 一键还原默认hosts文件

:: 密码验证
set "input="
set /p "input=请输入操作密码："
if not "%input%"=="9178" (
    echo 密码错误，无法执行！
    pause>nul
    exit
)

set "hostsPath=C:\Windows\System32\drivers\etc\hosts"
set "backupHostsPath=C:\Windows\System32\drivers\etc\hosts.backup"

:: 检查是否以管理员身份运行
net session >nul 2>&1
if %errorLevel% NEQ 0 (
    echo 错误：请右键点击此脚本，选择【以管理员身份运行】！
    pause>nul
    exit
)

:: 备份当前hosts（防止还原出错）
copy /y "%hostsPath%" "%backupHostsPath%" >nul

:: 写入系统默认hosts内容
echo # Copyright (c) 1993-2009 Microsoft Corp. > "%hostsPath%"
echo # >> "%hostsPath%"
echo # This is a sample HOSTs file used by Microsoft TCP/IP for Windows. >> "%hostsPath%"
echo # >> "%hostsPath%"
echo # This file contains the mappings of IP addresses to host names. Each >> "%hostsPath%"
echo # entry should be kept on an individual line. The IP address should >> "%hostsPath%"
echo # be placed in the first column followed by the corresponding host name. >> "%hostsPath%"
echo # The IP address and the host name should be separated by at least one >> "%hostsPath%"
echo # space. >> "%hostsPath%"
echo # >> "%hostsPath%"
echo # Additionally, comments (such as these) may be inserted on individual >> "%hostsPath%"
echo # lines or following the machine name denoted by a '#' symbol. >> "%hostsPath%"
echo # >> "%hostsPath%"
echo # For example: >> "%hostsPath%"
echo # >> "%hostsPath%"
echo #      102.54.94.97     rhino.acme.com          # source server >> "%hostsPath%"
echo #       38.25.63.10     x.acme.com              # x client host >> "%hostsPath%"
echo # localhost name resolution is handled within DNS itself. >> "%hostsPath%"
echo #	127.0.0.1       localhost >> "%hostsPath%"
echo #	::1             localhost >> "%hostsPath%"

:: 刷新DNS缓存
ipconfig /flushdns >nul

echo 成功还原默认hosts文件！
echo 已备份原hosts文件至：C:\Windows\System32\drivers\etc\hosts.backup
pause>nul

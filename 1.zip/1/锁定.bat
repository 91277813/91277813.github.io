@echo off
chcp 65001 >nul
title 锁定抖音访问

:: 修改hosts屏蔽抖音
echo. >> C:\Windows\System32\drivers\etc\hosts
echo 127.0.0.1 www.douyin.com >> C:\Windows\System32\drivers\etc\hosts
echo 127.0.0.1 douyin.com >> C:\Windows\System32\drivers\etc\hosts
echo 127.0.0.1 v.douyin.com >> C:\Windows\System32\drivers\etc\hosts

:: 刷新DNS
ipconfig /flushdns >nul

echo 已锁定抖音访问，需输入密码才能解锁。
pause
